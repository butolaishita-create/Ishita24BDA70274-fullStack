import './App.css'
import Productcards from './ProductCards'

function App() {
  return (
    <>
      <Productcards>  </Productcards>
    </>
  )
}

export default App
