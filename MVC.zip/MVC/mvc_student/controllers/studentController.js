const studentModel = require('../models/studentModel');

exports.showForm = (req, res) => {
    res.render('index');
};

exports.addStudent = (req, res) => {
    const { name, age } = req.body;
    studentModel.addStudent({ name, age });
    res.redirect('/students');
};

exports.getStudents = (req, res) => {
    const students = studentModel.getStudents();
    res.render('students', { students });
};