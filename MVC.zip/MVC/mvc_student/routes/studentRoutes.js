const express = require('express');
const router = express.Router();
const studentController = require('../controllers/studentController');

router.get('/', studentController.showForm);
router.post('/add', studentController.addStudent);
router.get('/students', studentController.getStudents);

module.exports = router;